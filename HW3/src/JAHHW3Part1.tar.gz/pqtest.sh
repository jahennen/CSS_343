#! /bin/bash

# Author: Jay Hennen

# Simple script to compile/run PQtest

g++ -Wall -g -o pqtest PQTest.cpp

./pqtest
